from .main import Signal, vhdl, timing
from .bram import BRAM
from .component import Component, FromText
from .build import build